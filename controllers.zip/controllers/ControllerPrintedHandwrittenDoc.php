<?php

class ControllerPrintedHandwrittenDoc {

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }


    public function getPrintedOrHandwrittenDocWithID($PrintedOrHandwrittenDocID, $CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `PrintedOrHandWrittenDocs_Details`
        WHERE PrintedOrHandwrittenDocID = :PrintedOrHandwrittenDocID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('PrintedOrHandwrittenDocID' => $PrintedOrHandwrittenDocID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->PrintedOrHandwrittenDocID = $row['PrintedOrHandwrittenDocID'];
            $itm->cultureID = $row['CultureID'];
            $itm->Kind = $row['Kind'];
            $itm->title = $row['Title'];
            $itm->subtitle = $row['subtitle'];
            $itm->SourceDetails = $row['SourceDetails'];
            $itm->Creator = $row['Creator'];
            $itm->Legende = $row['Legende'];
            $itm->Description = $row['Description'];
            $itm->BackView = $row['BackView'];
            $itm->Sponsor = $row['Sponsor'];
            $itm->CommentsPlainText = $row['CommentsPlainText'];
            $itm->SourceDetailsPlainText = $row['SourceDetailsPlainText'];
            $itm->SourceDetails = $row['SourceDetails'];
            $itm->Comments = $row['Comments'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

    

   public function getAllPrintedOrHandWrittenDoc($CultureID,$PageSize = NULL, $RecordOffest = NULL) {

        $query = 'SELECT PrintedOrHandwrittenDocID,Title,CultureID  FROM PrintedOrHandWrittenDocs_Details 
            WHERE CultureID = :CultureID';

        if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query);
        $result = $stmt->execute( array('CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new PrintedHandwrittenDoc();



            $itm->PrintedOrHandwrittenDocID = $row['PrintedOrHandwrittenDocID'];
            $itm->CultureID = $row['CultureID'];
            $itm->title = $row['Title'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }




       public function getAllPrintedOrHandWrittenDocCount($CultureID) {

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM PrintedOrHandWrittenDocs_Details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }

    public function getHandPrintedWithID($PrintedOrHandwrittenDocID) 
    {

        $stmt = $this->pdo->prepare('SELECT *
        	FROM PrintedOrHandWrittenDocs
            
        	WHERE PrintedOrHandwrittenDocID = :PrintedOrHandwrittenDocID ');

        $result = $stmt->execute( array('PrintedOrHandwrittenDocID' => $PrintedOrHandwrittenDocID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->PrintedOrHandwrittenDocID = $row['PrintedOrHandwrittenDocID'];
            $itm->SourceID = $row['SourceID'];
            $itm->CopyrightHeldByApan = $row['CopyrightHeldByApan'];
            $itm->copyrightHeldBy = $row['copyrightHeldBy'];
            $itm->IsOriginal = $row['IsOriginal'];
            $itm->Location = $row['Location'];
            $itm->PPI = $row['PPI'];
            $itm->IsColored = $row['IsColored'];
            $itm->OriginalCreationDate = $row['OriginalCreationDate'];
            $itm->CopyrightHeldByPlainText = $row['CopyrightHeldByPlainText'];

            


            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

       public function getHandPrintedSourceWithID($PrintedOrHandwrittenDocID ,$CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT PrintedOrHandWrittenDocs.*, PrintedOrHandwrittenSources_Details.*
            FROM PrintedOrHandWrittenDocs
            INNER JOIN PrintedOrHandwrittenSources_Details
            ON `PrintedOrHandWrittenDocs`.`SourceID` =  `PrintedOrHandwrittenSources_Details`.`PrintedOrHandwrittenSourceID`
            WHERE  PrintedOrHandwrittenDocID = :PrintedOrHandwrittenDocID AND CultureID = :CultureID');

        $result = $stmt->execute( array('PrintedOrHandwrittenDocID' => $PrintedOrHandwrittenDocID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->PrintedOrHandwrittenSourceID = $row['PrintedOrHandwrittenSourceID'];
            $itm->PrintedOrHandwrittenDocID = $row['PrintedOrHandwrittenDocID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['LookupValue'];
            $itm->SourceID = $row['SourceID'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }





 public function getHandPrintedDateWithID($PrintedOrHandwrittenDocID) 
 
    {

        $stmt = $this->pdo->prepare('SELECT PrintedOrHandWrittenDocs.*, generalized_time.*
            FROM PrintedOrHandWrittenDocs
            INNER JOIN generalized_time
            ON `PrintedOrHandWrittenDocs`.`OriginalCreationDate` =  `generalized_time`.`GeneralizedTimeID`
            WHERE  PrintedOrHandwrittenDocID = :PrintedOrHandwrittenDocID');

        $result = $stmt->execute( array('PrintedOrHandwrittenDocID' => $PrintedOrHandwrittenDocID ));

        $array = array();
        //$ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->OriginalCreationDate = $row['OriginalCreationDate'];
            $itm->GeneralizedTimeID = $row['GeneralizedTimeID'];
            $itm->IsPoint = $row['IsPoint'];
            $itm->PrintedOrHandwrittenDocID = $row['PrintedOrHandwrittenDocID'];
            $itm->YearInfo = $row['YearInfo'];
            $itm->MonthInfo = $row['MonthInfo'];
            $itm->DayInfo = $row['DayInfo'];
            $itm->ca = $row['ca'];

            //$array[$ind] = $itm;
            //$ind++;

          }

        return $itm;
    }



    public function getKeywordFromPrintedHandwrittenDoc($KeywordPerRecordID, $CultureID){   //DISPLAY KEYWORDS FOR AUDIOVISUAL

        $stmt = $this->pdo->prepare('SELECT `keywords_per_record`.`RecordID`,
             `keywords_per_record`.`KeywordID`,`keywords_details`.`KeywordID`,
             `keywords_details`.`KeywordTranslation`,`keywords_details`.`CultureID`
            FROM `keywords_per_record` 
            INNER JOIN `keywords_details`
            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
            WHERE `keywords_per_record`.`RecordID` = :KeywordPerRecordID AND `keywords_details`.`CultureID` = :CultureID;');

        $stmt->execute( array('KeywordPerRecordID' => $KeywordPerRecordID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->RecordID = $row['RecordID'];
            $itm->KeywordID = $row['KeywordID'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];
           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  


    public function getUsageFromHandWtitten($accompanyingObjectID){   

        $stmt = $this->pdo->prepare('SELECT accompanyingUsage.* , item_usage_types.* , generalized_time.* 

            FROM accompanyingUsage
            INNER JOIN item_usage_types
            ON  `accompanyingUsage`.`usageTypeID` = `item_usage_types`.`UsageTypeID`
            LEFT OUTER JOIN generalized_time
            ON generalized_time.GeneralizedTimeID = accompanyingUsage.timeID
           

            WHERE  accompanyingObjectID = :accompanyingObjectID;  ');

        $stmt->execute( array('accompanyingObjectID' => $accompanyingObjectID));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->timeID = $row['timeID'];
            $itm->usageTypeID = $row['usageTypeID'];
            $itm->accompanyingObjectID = $row['accompanyingObjectID'];
            $itm->accompanyingUsageID = $row['accompanyingUsageID'];
            $itm->UsageTypeID = $row['UsageTypeID'];
            $itm->use = $row['StandardValue'];
            $itm->PeriodID = $row['PeriodID'];
            $itm->YearInfo = $row['YearInfo'];
            $itm->MonthInfo = $row['MonthInfo'];
            $itm->DayInfo = $row['DayInfo'];
            $itm->ca = $row['ca'];
            $itm->IsPoint = $row['IsPoint'];
            $itm->Info = $row['Info'];
            $itm->CreatedOn = $row['CreatedOn'];
            $itm->minus = $row['minus'];
            $itm->plus = $row['plus'];
      

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  



 public function getUsageDetailsFromHandWrittenPrinted($accompanyingObjectID, $cultureID){

        $stmt = $this->pdo->prepare('SELECT accompanyingUsage.* ,accompanyingUsage_details.*

            FROM accompanyingUsage
            LEFT OUTER JOIN accompanyingUsage_details
            ON accompanyingUsage.accompanyingUsageID = accompanyingUsage_details.accompanyingUsageID

            WHERE  accompanyingObjectID = :accompanyingObjectID AND cultureID = :cultureID;  ');

        $stmt->execute( array('accompanyingObjectID' => $accompanyingObjectID, 'cultureID' => $cultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->accompanyingObjectID = $row['accompanyingObjectID'];
            $itm->accompanyingUsageID = $row['accompanyingUsageID'];
            $itm->cultureID = $row['cultureID'];
            $itm->occasion = $row['occasion'];
            $itm->comments = $row['comments'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  



      public function getAllHandPrintedSources($CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `PrintedOrHandwrittenSources_Details`
               WHERE CultureID = :CultureID; ');

        $result = $stmt->execute( array('CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new PrintedHandwrittenDoc();
            $itm->PrintedOrHandwrittenSourceID = $row['PrintedOrHandwrittenSourceID'];
            $itm->cultureID = $row['cultureID'];
            $itm->LookupValue = $row['LookupValue'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


}