<?php

class ControllerBiography{

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }




	public function getBiographyWithID($biographyID, $CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `biographies_details`
        WHERE biographyID = :biographyID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('biographyID' => $biographyID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Biography();
            $itm->biographyID = $row['biographyID'];
            $itm->CultureID = $row['CultureID'];
            $itm->FullName = $row['FullName'];
            $itm->Office = $row['Office'];
            $itm->HonorTitle = $row['HonorTitle'];
            $itm->Nickname = $row['Nickname'];
            $itm->CareerPlainText = $row['CareerPlainText'];
            $itm->Education = $row['Education'];
            $itm->ServiceDetails = $row['ServiceDetails'];
            $itm->DeathLocation = $row['DeathLocation'];
            $itm->BurialLocation = $row['BurialLocation'];
            $itm->HistoricalData = $row['HistoricalData'];
            $itm->BirthLocation = $row['BirthLocation'];
            $itm->Profession = $row['Profession'];
            $itm->CommentsPlainText = $row['CommentsPlainText'];
            $itm->HistoricalDataPlainText = $row['HistoricalDataPlainText'];
       



            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }




   
    public function getAllBiography($CultureID, $PageSize = NULL, $RecordOffest = NULL)  {   //$PageSize = items per page  ,  $RecordOffset = 

        $query = 'SELECT biographyID,FullName,CultureID 
         FROM biographies_details 
         WHERE CultureID = :CultureID';

       if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query);      

        $result = $stmt->execute( array('CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {


            $itm = new Biography();

            $itm->biographyID = $row['biographyID'];
            $itm->CultureID = $row['CultureID'];
            $itm->FullName = $row['FullName'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;
    }

 

  public function getAllBiographyCount($CultureID) {  

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM biographies_details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }



	public function getKeywordFromBiographyID($KeywordPerRecordID, $CultureID) {   //DISPLAY KEYWORDS FOR BIOGRAPHY
        $stmt = $this->pdo->prepare('SELECT `keywords_per_record`.`RecordID`,
             `keywords_per_record`.`KeywordID`,`keywords_details`.`KeywordID`,
             `keywords_details`.`KeywordTranslation`,`keywords_details`.`CultureID`
            FROM `keywords_per_record` 
            INNER JOIN `keywords_details`
            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
            WHERE `keywords_per_record`.`RecordID` = :KeywordPerRecordID AND `keywords_details`.`CultureID` = :CultureID;');

        $stmt->execute( array('KeywordPerRecordID' => $KeywordPerRecordID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Biography();
            $itm->RecordID = $row['RecordID'];
            $itm->KeywordID = $row['KeywordID'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];
           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  




}