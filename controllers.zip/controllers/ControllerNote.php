<?php

class ControllerNote {

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }




    public function getNotesDetailsWithID($NoteID, $CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `Notes_Details`
        WHERE NoteID = :NoteID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('NoteID' => $NoteID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->NoteID = $row['NoteID'];
            $itm->cultureID = $row['cultureID'];
            $itm->Abbreviation = $row['Abbreviation'];
            $itm->title = $row['Title'];
            $itm->subtitle = $row['Subtitle'];
            $itm->Authors = $row['Authors'];
            $itm->Translators = $row['Translators'];
            $itm->Content = $row['Content'];
            $itm->SubmissionInfo = $row['SubmissionInfo'];
            $itm->UsageInfo = $row['UsageInfo'];
            $itm->OtherOwners = $row['OtherOwners'];
            $itm->Notes = $row['Notes'];
            $itm->CommentsPlainText = $row['CommentsPlainText'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

       public function getAllNoteCount($CultureID) {

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM Notes_Details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }



      public function getAllNotes($CultureID,$PageSize = NULL, $RecordOffest = NULL) {

       $query = 'SELECT NoteID,title,CultureID  FROM Notes_Details WHERE CultureID = :CultureID';
       
        if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query);      

        

        $result = $stmt->execute( array('CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new Note();



            $itm->NoteID = $row['NoteID'];
            $itm->CultureID = $row['CultureID'];
            $itm->title = $row['title'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }






    public function getNotesWithID($NoteID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `Notes`
        WHERE NoteID = :NoteID; ');

        $result = $stmt->execute( array('NoteID' => $NoteID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->NoteID = $row['NoteID'];
            $itm->PageNumber = $row['PageNumber'];
            $itm->IsExcerpt = $row['IsExcerpt'];
            $itm->ExcerptPages = $row['ExcerptPages'];
            $itm->Location = $row['Location'];
            $itm->CopyrightHeldByApan = $row['CopyrightHeldByApan'];
            $itm->CopyrightHeldBy = $row['CopyrightHeldBy'];
            $itm->PrivateData = $row['PrivateData'];
            $itm->CopyrightHeldByPlainText = $row['CopyrightHeldByPlainText'];
        

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }




    public function getKeywordForNotes($KeywordPerRecordID, $CultureID){   

        $stmt = $this->pdo->prepare('SELECT `keywords_per_record`.`RecordID`,
             `keywords_per_record`.`KeywordID`,`keywords_details`.`KeywordID`,
             `keywords_details`.`KeywordTranslation`,`keywords_details`.`CultureID`
            FROM `keywords_per_record` 
            INNER JOIN `keywords_details`
            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
            WHERE `keywords_per_record`.`RecordID` = :KeywordPerRecordID AND `keywords_details`.`CultureID` = :CultureID;');

        $stmt->execute( array('KeywordPerRecordID' => $KeywordPerRecordID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->RecordID = $row['RecordID'];
            $itm->KeywordID = $row['KeywordID'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];
           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  


   public function getCharacterizationOfNote($ItemID, $CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `accObjectsToCharacterization` 
            INNER JOIN accObjectsCharacterization_details ON accObjectsToCharacterization.ChoiceID = accObjectsCharacterization_details.accompanyingObjectCharactID 
            WHERE ItemID = :ItemID AND CultureID = :CultureID ');

        $result = $stmt->execute( array('ItemID' => $ItemID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->ItemID = $row['ItemID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->characterization = $row['lookupValue'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


          public function getAllCharacterizationOfNotes($CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT accObjectsCharacterization_details.*,accObjectsCharacterization.*
        FROM `accObjectsCharacterization` 
            INNER JOIN accObjectsCharacterization_details 
            ON accObjectsCharacterization.accObjCharacterizationID = accObjectsCharacterization_details.accompanyingObjectCharactID 
            WHERE CultureID = :CultureID AND accObjectsCharacterization.itemTypeID = 7');

        $result = $stmt->execute( array('CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->ItemID = $row['ItemID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->lookupValue = $row['lookupValue'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }





   public function getPublicationTypeOfNote($ItemID, $CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `NotePublicationTypesToObjects` 
            INNER JOIN NotePublicationTypes_Details ON NotePublicationTypesToObjects.ChoiceID = NotePublicationTypes_Details.NotePublicationTypeID 
            WHERE ItemID = :ItemID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('ItemID' => $ItemID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Note();
            $itm->ItemID = $row['ItemID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->NotePublicationTypeID = $row['NotePublicationTypeID'];
            $itm->publicationType = $row['LookupValue'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

}