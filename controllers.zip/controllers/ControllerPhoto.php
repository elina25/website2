<?php

class ControllerPhoto {

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }






    public function getAllPhotos($CultureID,$PageSize = NULL, $RecordOffest = NULL) {

        $query ='SELECT PhotoID,Title,documentPath,CultureID  FROM Photos_Details 
            INNER JOIN accompanyingObjects ON accompanyingObjects.accompanyingObjectID = Photos_Details.PhotoID
            WHERE CultureID = :CultureID ';

    if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query);    
        

        $result = $stmt->execute( array('CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new Photo();

            $itm->photoID = $row['PhotoID'];
            $itm->CultureID = $row['CultureID'];
            $itm->title = $row['Title'];
            $itm->documentPath = $row['documentPath'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }



   public function getPhotosWithID($PhotoID) {

        $query ='SELECT * FROM Photos
            WHERE PhotoID = :PhotoID ';

    

        $stmt = $this->pdo->prepare($query);    
        

        $result = $stmt->execute( array('PhotoID' => $PhotoID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new Photo();

            $itm->photoID = $row['PhotoID'];
            $itm->SourceID = $row['SourceID'];
            $itm->CopyrightHeldByApan = $row['CopyrightHeldByApan'];
            $itm->copyrightHeldBy = $row['copyrightHeldBy'];
            $itm->IsOriginal = $row['IsOriginal'];
            $itm->kindID = $row['kindID'];
            $itm->QualityID = $row['QualityID'];
            $itm->Location = $row['Location'];
            $itm->PPI = $row['PPI'];
            $itm->ShootingTimeID = $row['ShootingTimeID'];
            $itm->IsColored = $row['IsColored'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }






        public function getPhotosDetailsWithID($PhotoID, $CultureID){

         $stmt = $this->pdo->prepare('SELECT * FROM Photos_Details 
             INNER JOIN accompanyingObjects ON accompanyingObjects.accompanyingObjectID = Photos_Details.PhotoID
            WHERE PhotoID = :PhotoID  AND CultureID = :CultureID; ');
        

        $result = $stmt->execute( array('PhotoID' => $PhotoID , 'CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) 
        {
            $itm = new Photo();
            $itm->photoID = $row['PhotoID'];
            $itm->title = $row['Title'];
            $itm->CultureID = $row['CultureID'];
            $itm->documentPath = $row['documentPath'];
            $itm->Photographer = $row['Photographer'];
            $itm->SourceDetails = $row['SourceDetails'];
            $itm->KindDetails = $row['KindDetails'];
            $itm->QualityDetails = $row['QualityDetails'];
            $itm->DayHour = $row['DayHour'];
            $itm->Occasion = $row['Occasion'];
            $itm->PhotoDescription = $row['PhotoDescription'];
            $itm->OtherInfo = $row['OtherInfo'];
            $itm->Comments = $row['Comments'];
            $itm->CreatedOn = $row['CreatedOn'];
            $itm->CommentsPlainText = $row['CommentsPlainText'];


          
            $array[$ind] = $itm;
            $ind++;


        }

        return $array;

}



        public function getAllPhotoCount($CultureID) {

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM Photos_Details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }




 public function GetAllRelationsWithfriendlyNameFromPhotosToReligiousMonument($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT religiousMonumentsDetails.friendlyName, religiousMonumentsDetails.ReligiousMonumentId,religiousMonumentsDetails.cultureID
                                  FROM religiousMonumentsDetails
                                  where `ReligiousMonumentId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

  public function GetAllRelationsWithfriendlyNameFromPhotosTochristianorthodoxMonumentsDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT christianorthodoxMonumentsDetails.friendlyName, christianorthodoxMonumentsDetails.ChristianorthodoxMonumentId,christianorthodoxMonumentsDetails.cultureID
                                  FROM christianorthodoxMonumentsDetails
                                  where `ChristianorthodoxMonumentId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

   public function GetAllRelationsWithfriendlyNameFromPhotosToArtworks_details($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT artworks_details.friendlyName, artworks_details.ArtworkID, artworks_details.cultureID
                    FROM artworks_details
                    where `ArtworkID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

    public function GetAllRelationsWithfriendlyNameFromPhotosToEducationalFoundationDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT educationalFoundationDetails.friendlyName, educationalFoundationDetails.EducationFoundationId, educationalFoundationDetails.cultureID
                    FROM educationalFoundationDetails
                    where `EducationFoundationId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }


    public function GetAllRelationsWithfriendlyNameFromPhotosToEpigraphsDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT epigraphsDetails.friendlyName, epigraphsDetails.EpigraphId, epigraphsDetails.cultureID
                    FROM epigraphsDetails
                    where `EducationFoundationId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

     public function GetAllRelationsWithfriendlyNameFromPhotosTocommunityDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT communityDetails.friendlyName, communityDetails.CommunityId, communityDetails.cultureID
                    FROM epigraphsDetails
                    where `CommunityId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

     public function GetAllRelationsWithfriendlyNameFromPhotosTocemeteryDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT cemeteryDetails.friendlyName, cemeteryDetails.CemeteryId, cemeteryDetails.cultureID
                    FROM epigraphsDetails
                    where `CemeteryId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }
 
 public function GetAllRelationsWithfriendlyNameFromPhotosToArchRel($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT archeologicalReligiousMonumentsDetails.friendlyName, archeologicalReligiousMonumentsDetails.ArchReligiousId, archeologicalReligiousMonumentsDetails.cultureID
                    FROM archeologicalReligiousMonumentsDetails
                    where `ArchReligiousId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

  public function GetAllRelationsWithfriendlyNameFromPhotosToArchSite($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT archeologicalSiteDetails.friendlyName, archeologicalSiteDetails.ArchSiteID, archeologicalSiteDetails.cultureID
                    FROM archeologicalSiteDetails
                    where `ArchSiteID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }

   public function GetAllRelationsWithfriendlyNameFromPhotosToFortress($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT fortressesDetails.friendlyName, fortressesDetails.FortressId, fortressesDetails.cultureID
                    FROM fortressesDetails
                    where `ArchSiteID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 }


   public function GetAllRelationsWithfriendlyNameFromPhotosToTomb($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT tombsDetails.name, tombsDetails.TombId, tombsDetails.cultureID
                    FROM tombsDetails
                    where `TombId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->name = $row['name'];
            array_push($items, $itm);

        }

          

        return $items;

 }
   
  
     public function GetAllRelationsWithfriendlyNameFromPhotosToMuseums($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT museumsDetails.friendlyName, museumsDetails.MuseumId, museumsDetails.cultureID
                    FROM museumsDetails
                    where `MuseumId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 
   

    public function GetAllRelationsWithfriendlyNameFromPhotosToExhibition($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT exhibitionDetails.friendlyName, exhibitionDetails.ExhibitionId, exhibitionDetails.cultureID
                    FROM exhibitionDetails
                    where `ExhibitionId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 

    public function GetAllRelationsWithfriendlyNameFromPhotosToAdminBuildings($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT administrationBuildingsDetails.friendlyName, administrationBuildingsDetails.AdminBuildingId, administrationBuildingsDetails.cultureID
                    FROM administrationBuildingsDetails
                    where `AdminBuildingId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 

     public function GetAllRelationsWithfriendlyNameFromPhotosToWelfareBuilding($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT welfareBuildingsDetails.friendlyName, welfareBuildingsDetails.WelfareBuildingId, welfareBuildingsDetails.cultureID
                    FROM welfareBuildingsDetails
                    where `WelfareBuildingId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 

     public function GetAllRelationsWithfriendlyNameFromPhotosToInfrastructureBuilding($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT infrastructureBuildingsDetails.friendlyName, infrastructureBuildingsDetails.InfrastructureBuildingId, infrastructureBuildingsDetails.cultureID
                    FROM infrastructureBuildingsDetails
                    where `InfrastructureBuildingId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 


     public function GetAllRelationsWithfriendlyNameFromPhotosToResidentialBuildingId($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT socialResidentialBuildingDetails.friendlyName, socialResidentialBuildingDetails.ResidentialBuildingId, socialResidentialBuildingDetails.cultureID
                    FROM socialResidentialBuildingDetails
                    where `InfrastructureBuildingId` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->friendlyName = $row['friendlyName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 

   public function GetAllRelationsWithfriendlyNameFromPhotosToCoin($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT coins_details.frontView, coins_details.coinID, coins_details.cultureID
                    FROM coins_details
                    where `coinID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->frontView = $row['frontView'];
            array_push($items, $itm);

        }

          

        return $items;

 } 


   public function GetAllRelationsWithfriendlyNameFromPhotosToPersonDetails($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT persons_details.fullName, persons_details.personID, persons_details.cultureID
                    FROM persons_details
                    where `personID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->fullName = $row['fullName'];
            array_push($items, $itm);

        }

          

        return $items;

 } 


   public function GetAllRelationsWithfriendlyNameFromPhotosToReligiousEvent($item_id,$CultureID){

    $stmt = $this->pdo->prepare('SELECT religiousEventsDetails.title, religiousEventsDetails.religiousEventID, religiousEventsDetails.cultureID
                    FROM religiousEventsDetails
                    where `religiousEventID` =:item_id AND CultureID =:CultureID');

    $stmt->execute(array('item_id' => $item_id, 'CultureID' => $CultureID));

    $items = array();

    foreach ($stmt as $row) {

        // do something with $row
            $itm = new stdClass();
            $itm->title = $row['title'];
            array_push($items, $itm);

        }

          

        return $items;

 } 

}