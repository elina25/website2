<?php

class ControllerAudioVisual{

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }







    public function getAudioVisualWithID($audioVisualID, $CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `audioVisuals_details`
        WHERE audioVisualID = :audioVisualID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('audioVisualID' => $audioVisualID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->audioVisualID = $row['audioVisualID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ID = $row['ID'];
            $itm->title = $row['title'];
            $itm->subtitle = $row['subtitle'];
            $itm->language = $row['language'];
            $itm->director = $row['director'];
            $itm->composer = $row['composer'];
            $itm->direction = $row['direction'];
            $itm->synopsis = $row['synopsis'];
            $itm->occassion = $row['occassion'];
            $itm->duration = $row['duration'];
            $itm->format = $row['format'];
            $itm->digitizationform = $row['digitizationform'];
            $itm->interviewData = $row['interviewData'];
            $itm->textsBy = $row['textsBy'];
            $itm->musicBy = $row['musicBy'];
            $itm->researchBy = $row['researchBy'];
            $itm->producedBy = $row['producedBy'];
            $itm->otherInfo = $row['otherInfo'];
            $itm->cinematographer = $row['cinematographer'];
            $itm->othersInvolved = $row['othersInvolved'];
            $itm->comments = $row['commentsPlainText'];
            $itm->createdOn = $row['createdOn'];
            $itm->uniqueName = $row['uniqueName'];



            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }



    public function getAllAudiovisual($cultureID,$PageSize = NULL, $RecordOffest = NULL) {

        $query = 'SELECT audioVisualID,title,cultureID  
        FROM audioVisuals_details 
        WHERE cultureID = :cultureID';

        if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query);      

        $result = $stmt->execute( array('cultureID' => $cultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new AudioVisual();



            $itm->audioVisualID = $row['audioVisualID'];
            $itm->cultureID = $row['cultureID'];
            $itm->title = $row['title'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }



    public function getAllAudiovisualCount($CultureID) {

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM audioVisuals_details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }



    public function getAudioVisualDetailsWithID($audioVisualID) 
    {

        $stmt = $this->pdo->prepare('SELECT *
        FROM `audioVisuals`
       
        WHERE audioVisualID = :audioVisualID  ');

        $result = $stmt->execute( array('audioVisualID' => $audioVisualID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->audioVisualID = $row['audioVisualID'];
            $itm->kindID = $row['kindID'];
            $itm->copyrightHeldByApan = $row['copyrightHeldByApan'];
            $itm->copyrightHeldBy = $row['copyrightHeldBy'];
            $itm->privateData = $row['privateData'];
            $itm->recordingTimeID = $row['recordingTimeID'];
            $itm->Video = $row['Video'];
      


            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


public function getKeywordForAllAudiovisual($CultureID){   //GET KEYWORDS FOR ACCOMPANYING OBJECT



$stmt = $this->pdo->prepare("SELECT distinct keywords_per_record.KeywordID, keywords_per_record.TableName,
                             keywords_details.KeywordTranslation, keywords_details.KeywordID, keywords_details.CultureID
                            FROM `keywords_per_record` 
                            INNER JOIN keywords_details
                            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
                            WHERE TableName LIKE 'tAudioVisuals'  AND CultureID =:CultureID ;");

$stmt->execute( array('CultureID' => $CultureID ));

$array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Keyword();
            $itm->KeywordID = $row['KeywordID'];
            $itm->TableName = $row['TableName'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];

           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }




    public function getKindOfAudioVisualWithID($audioVisualID, $CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `audioVisuals`
        LEFT OUTER JOIN visualKinds_details
        ON audioVisuals.kindID = visualKinds_details.audioVisualKindID
        WHERE audioVisualID = :audioVisualID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('audioVisualID' => $audioVisualID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->audioVisualID = $row['audioVisualID'];
            $itm->audioVisualKindID = $row['audioVisualKindID'];
            $itm->cultureID = $row['cultureID'];
            $itm->lookupValue = $row['lookupValue'];
            $itm->kindID = $row['kindID'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


  public function getAllKindsOfAudioVisuals($CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `visualKinds_details`
               WHERE CultureID = :CultureID; ');

        $result = $stmt->execute( array('CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->audioVisualKindID = $row['audioVisualKindID'];
            $itm->cultureID = $row['cultureID'];
            $itm->lookupValue = $row['lookupValue'];
            $itm->kindID = $row['kindID'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

      public function getCharacterizationOfAudioVisualWithID($audioVisualID, $CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `audioVisuals` 
            LEFT OUTER JOIN accObjectsToCharacterization ON audioVisuals.audioVisualID = accObjectsToCharacterization.ItemID 
            INNER JOIN accObjectsCharacterization_details ON accObjectsToCharacterization.ChoiceID = accObjectsCharacterization_details.accompanyingObjectCharactID 
            WHERE audioVisualID = :audioVisualID AND CultureID = :CultureID ');

        $result = $stmt->execute( array('audioVisualID' => $audioVisualID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->audioVisualID = $row['audioVisualID'];
            $itm->ItemID = $row['ItemID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->characterization = $row['lookupValue'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


      public function getAllCharacterizationOfAudioVisual($CultureID)  
    {

        $stmt = $this->pdo->prepare('SELECT accObjectsCharacterization_details.*,accObjectsCharacterization.*
        FROM `accObjectsCharacterization` 
            INNER JOIN accObjectsCharacterization_details 
            ON accObjectsCharacterization.accObjCharacterizationID = accObjectsCharacterization_details.accompanyingObjectCharactID 
            WHERE CultureID = :CultureID AND accObjectsCharacterization.itemTypeID = 5');

        $result = $stmt->execute( array('CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->ItemID = $row['ItemID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->lookupValue = $row['lookupValue'];
            
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


    public function getKeywordFromAudioVisualID($KeywordPerRecordID, $CultureID){   //DISPLAY KEYWORDS FOR AUDIOVISUAL

        $stmt = $this->pdo->prepare('SELECT `keywords_per_record`.`RecordID`,
             `keywords_per_record`.`KeywordID`,`keywords_details`.`KeywordID`,
             `keywords_details`.`KeywordTranslation`,`keywords_details`.`CultureID`
            FROM `keywords_per_record` 
            INNER JOIN `keywords_details`
            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
            WHERE `keywords_per_record`.`RecordID` = :KeywordPerRecordID AND `keywords_details`.`CultureID` = :CultureID;');

        $stmt->execute( array('KeywordPerRecordID' => $KeywordPerRecordID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->RecordID = $row['RecordID'];
            $itm->KeywordID = $row['KeywordID'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];
           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  




    public function getUsageFromAudioVisualID($accompanyingObjectID){ 

        $stmt = $this->pdo->prepare('SELECT accompanyingUsage.* , item_usage_types.* , generalized_time.* 

            FROM accompanyingUsage
            INNER JOIN item_usage_types
            ON  `accompanyingUsage`.`usageTypeID` = `item_usage_types`.`UsageTypeID`
            LEFT OUTER JOIN generalized_time
            ON generalized_time.GeneralizedTimeID = accompanyingUsage.timeID
           

            WHERE  accompanyingObjectID = :accompanyingObjectID;  ');

        $stmt->execute( array('accompanyingObjectID' => $accompanyingObjectID));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->timeID = $row['timeID'];
            $itm->usageTypeID = $row['usageTypeID'];
            $itm->accompanyingObjectID = $row['accompanyingObjectID'];
            $itm->accompanyingUsageID = $row['accompanyingUsageID'];
            $itm->UsageTypeID = $row['UsageTypeID'];
            $itm->use = $row['StandardValue'];
            $itm->PeriodID = $row['PeriodID'];
            $itm->YearInfo = $row['YearInfo'];
            $itm->MonthInfo = $row['MonthInfo'];
            $itm->DayInfo = $row['DayInfo'];
            $itm->ca = $row['ca'];
            $itm->IsPoint = $row['IsPoint'];
            $itm->Info = $row['Info'];
            $itm->CreatedOn = $row['CreatedOn'];
            $itm->minus = $row['minus'];
            $itm->plus = $row['plus'];
      

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  





    public function getUsageDetailsFromAudioVisualID($accompanyingObjectID, $cultureID){

        $stmt = $this->pdo->prepare('SELECT accompanyingUsage.* ,accompanyingUsage_details.*

            FROM accompanyingUsage
            LEFT OUTER JOIN accompanyingUsage_details
            ON accompanyingUsage.accompanyingUsageID = accompanyingUsage_details.accompanyingUsageID

            WHERE  accompanyingObjectID = :accompanyingObjectID AND cultureID = :cultureID;  ');

        $stmt->execute( array('accompanyingObjectID' => $accompanyingObjectID, 'cultureID' => $cultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new AudioVisual();
            $itm->accompanyingObjectID = $row['accompanyingObjectID'];
            $itm->accompanyingUsageID = $row['accompanyingUsageID'];
            $itm->cultureID = $row['cultureID'];
            $itm->occasion = $row['occasion'];
            $itm->comments = $row['comments'];
            $itm->usageTypeID = $row['usageTypeID'];

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  






}