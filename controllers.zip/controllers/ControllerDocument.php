<?php

class ControllerDocument{

    private $db;
    private $pdo;

    function __construct() {
        // connecting to database
        $this->db = new DB_Connect();
        $this->pdo = $this->db->connect();
    }

    function __destruct() {
        
    }



    public function getDetailsDocumentWithID($DocumentID, $CultureID) 
    {

        $stmt = $this->pdo->prepare('SELECT * FROM `Documents_Details`
        WHERE DocumentID = :DocumentID AND CultureID = :CultureID; ');

        $result = $stmt->execute( array('DocumentID' => $DocumentID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->DocumentID = $row['DocumentID'];
            $itm->cultureID = $row['cultureID'];
            $itm->ID = $row['ID'];
            $itm->title = $row['Title'];
            $itm->subtitle = $row['Subtitle'];
            $itm->Abbreviation = $row['Abbreviation'];
            $itm->Authors = $row['Authors'];
            $itm->Translators = $row['Translators'];
            $itm->SubmissionInfo = $row['SubmissionInfo'];
            $itm->UsageInfo = $row['UsageInfo'];
            $itm->Notes = $row['Notes'];
            $itm->DatesMentioned = $row['DatesMentioned'];
            $itm->Comments = $row['Comments'];
            $itm->CreatedOn = $row['CreatedOn'];
            $itm->Theme = $row['Theme'];
            $itm->CommentsPlainText = $row['CommentsPlainText'];
            $itm->AbbreviationPlainText = $row['AbbreviationPlainText'];
            $itm->TitlePlainText = $row['TitlePlainText'];
            $itm->SubtitlePlainText = $row['SubtitlePlainText'];
         
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


   public function getAllDocuments($CultureID,$PageSize = NULL, $RecordOffest = NULL) {

       $query = 'SELECT DocumentID,Title,cultureID  FROM Documents_Details
        WHERE CultureID = :CultureID';

        if(is_numeric($PageSize) && is_numeric($RecordOffest))
        {
            //echo '2:' . $PageSize . ' ' . $RecordOffest ;
            $query .= " LIMIT " .  $RecordOffest . "," . $PageSize;
        }

        $stmt = $this->pdo->prepare($query); 

        $result = $stmt->execute( array('CultureID' => $CultureID ));
        $array = array();

        $ind = 0;

        foreach ($stmt as $row) {

            $itm = new Document();



            $itm->DocumentID = $row['DocumentID'];
            $itm->CultureID = $row['cultureID'];
            $itm->title = $row['Title'];

          
            $array[$ind] = $itm;

            $ind++;


        }

        return $array;

    }


   public function getAllDocumentCount($CultureID) {

        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM Documents_Details WHERE CultureID = :CultureID;');
        $result = $stmt->execute( array('CultureID' => $CultureID ));

        //print_r($stmt);
        foreach ($stmt as $row) {
            //print_r($row);
            return $row[0];
        }

        return null;
    }


    public function getDocumentWithID($DocumentID) 
    {

        $stmt = $this->pdo->prepare('SELECT *
        FROM `Documents`
        INNER JOIN DocumentLanguages_Details 
        ON DocumentLanguages_Details.DocumentLanguageID = Documents.DocumentLanguageID
       
        WHERE DocumentID = :DocumentID  ');

        $result = $stmt->execute( array('DocumentID' => $DocumentID ));

        $array = array();
        
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->DocumentID = $row['DocumentID'];
            $itm->IsPublished = $row['IsPublished'];
            $itm->PublicationName = $row['PublicationName'];
            $itm->IssueNo = $row['IssueNo'];
            $itm->Pages = $row['Pages'];
            $itm->WebAddress = $row['WebAddress'];
            $itm->WritingYear = $row['WritingYear'];
            $itm->PageNumber = $row['PageNumber'];
            $itm->IsExpert = $row['IsExpert'];
            $itm->CopyrightHeldByApan = $row['CopyrightHeldByApan'];
            $itm->CopyrightHeldBy = $row['CopyrightHeldBy'];
            $itm->PrivateData = $row['PrivateData'];
            $itm->DocumentLanguageID = $row['DocumentLanguageID'];
            $itm->PublicationNamePlainText = $row['PublicationNamePlainText'];
            $itm->CopyrightHeldByPlainText = $row['CopyrightHeldByPlainText'];
            $itm->LookupValue = $row['LookupValue'];
      



          }

        return $itm;
    }



  public function getKeywordFromAudioVisualID($KeywordPerRecordID, $CultureID){   //DISPLAY KEYWORDS FOR AUDIOVISUAL

        $stmt = $this->pdo->prepare('SELECT `keywords_per_record`.`RecordID`,
             `keywords_per_record`.`KeywordID`,`keywords_details`.`KeywordID`,
             `keywords_details`.`KeywordTranslation`,`keywords_details`.`CultureID`
            FROM `keywords_per_record` 
            INNER JOIN `keywords_details`
            ON `keywords_per_record`.`KeywordID` = `keywords_details`.`KeywordID`
            WHERE `keywords_per_record`.`RecordID` = :KeywordPerRecordID AND `keywords_details`.`CultureID` = :CultureID;');

        $stmt->execute( array('KeywordPerRecordID' => $KeywordPerRecordID , 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->RecordID = $row['RecordID'];
            $itm->KeywordID = $row['KeywordID'];
            $itm->CultureID = $row['CultureID'];
            $itm->KeywordTranslation = $row['KeywordTranslation'];
           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }  




    public function getDocumentSourceWithID($ItemID, $CultureID){ //Get source of documents
    

        $stmt = $this->pdo->prepare('SELECT DocumentToSources.*, DocumentSources_Details.*
        FROM `DocumentToSources`
        INNER JOIN DocumentSources_Details 
        ON DocumentToSources.ChoiceID = DocumentSources_Details.DocumentSourceID
        WHERE ItemID = :ItemID AND CultureID =:CultureID');

         $stmt->execute( array('ItemID' => $ItemID, 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->DocumentSourceID = $row['DocumentSourceID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['LookupValue'];
       

           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }

        public function getDocumentFormWithID($ItemID, $CultureID){ //Get source of documents
    

        $stmt = $this->pdo->prepare('SELECT DocumentToForms.*, DocumentForms_Details.*
        FROM `DocumentToForms`
        INNER JOIN DocumentForms_Details 
        ON DocumentToForms.ChoiceID = DocumentForms_Details.DocumentFormID
        WHERE ItemID = :ItemID AND CultureID =:CultureID');

         $stmt->execute( array('ItemID' => $ItemID, 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->DocumentFormID = $row['DocumentFormID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['LookupValue'];
       

           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


       public function getDocumentOriginWithID($ItemID, $CultureID){ 
    

        $stmt = $this->pdo->prepare('SELECT DocumentToOrigins.*, DocumentOrigins_Details.*
        FROM `DocumentToOrigins`
        INNER JOIN DocumentOrigins_Details 
        ON DocumentToOrigins.ChoiceID = DocumentOrigins_Details.DocumentOriginID
        WHERE ItemID = :ItemID AND CultureID =:CultureID');

         $stmt->execute( array('ItemID' => $ItemID, 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->DocumentOriginID = $row['DocumentOriginID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['LookupValue'];
       

           

            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }


    public function getDocumentTypeContentWithID($ItemID, $CultureID){ //Get source of documents
    

        $stmt = $this->pdo->prepare('SELECT DocumentContentToTypes.*, DocumentContentTypes_Details.*
        FROM `DocumentContentToTypes`
        INNER JOIN DocumentContentTypes_Details 
        ON DocumentContentToTypes.ChoiceID = DocumentContentTypes_Details.DocumentContentTypeID
        WHERE ItemID = :ItemID AND CultureID =:CultureID');

         $stmt->execute( array('ItemID' => $ItemID, 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->DocumentContentTypeID = $row['DocumentContentTypeID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['LookupValue'];
       
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }



    public function getDocumentCharactWithID($ItemID, $CultureID){ 
    

        $stmt = $this->pdo->prepare('SELECT accObjectsToCharacterization.*, accObjectsCharacterization_details.*
        FROM `accObjectsToCharacterization`
        INNER JOIN accObjectsCharacterization_details 
        ON accObjectsToCharacterization.ChoiceID = accObjectsCharacterization_details.accompanyingObjectCharactID
        WHERE ItemID = :ItemID AND CultureID = :CultureID');

         $stmt->execute( array('ItemID' => $ItemID, 'CultureID' => $CultureID ));

        $array = array();
        $ind = 0;
        foreach ($stmt as $row)
         {
            //do something with $row
            $itm = new Document();
            $itm->ChoiceID = $row['ChoiceID'];
            $itm->accompanyingObjectCharactID = $row['accompanyingObjectCharactID'];
            $itm->CultureID = $row['CultureID'];
            $itm->LookupValue = $row['lookupValue'];
       
            $array[$ind] = $itm;
            $ind++;

          }

        return $array;
    }










}